package com.system.management.contact.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.system.management.contact.constant.RestMappingConstants;
import com.system.management.contact.request.CreateUserRequest;
import com.system.management.contact.request.EditUserRequest;
import com.system.management.contact.response.BaseApiResponse;
import com.system.management.contact.response.EditUserResponse;
import com.system.management.contact.response.ResponseBuilder;
import com.system.management.contact.service.UserService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@PostMapping(path = RestMappingConstants.TicketUri.CREATE_USER)
	public ResponseEntity<BaseApiResponse> createUser(@RequestBody CreateUserRequest requestModel) {
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(userService.createUser(requestModel));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
	
	@PutMapping(path = RestMappingConstants.TicketUri.EDIT_USER)
	public ResponseEntity<BaseApiResponse> editUser(@RequestBody EditUserRequest requestModel,
			HttpServletRequest request) {

		EditUserResponse response = userService.editUser(requestModel);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(response);
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
	
	@GetMapping(path = RestMappingConstants.TicketUri.VIEW_USER_BY_USER_ID)
	public ResponseEntity<BaseApiResponse> viewUserById( @RequestParam Long userId) {
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(userService.viewUserById(userId));
		return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
	}
	
	@GetMapping(path = RestMappingConstants.TicketUri.USER_LIST)
	public ResponseEntity<BaseApiResponse> viewUserList(HttpServletRequest request,
			@RequestParam(required = false) String firstName,
			@RequestParam(required = false) String lastName,
			@RequestParam(required = false) String email
			) {

		//System.out.println(paymentDate);
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(userService
				.viewUserList(firstName, lastName, email));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
	
	@PutMapping(path = RestMappingConstants.TicketUri.DELETE_USER)
	public ResponseEntity<BaseApiResponse> deleteUser(@RequestParam Long userId) {
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(userService.deleteUser(userId));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}


	}


package com.system.management.contact.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.system.management.contact.entity.UserEntity;

//@Repository
public interface UserRepository extends JpaRepository<UserEntity, Long> {

	  @Query("SELECT ce FROM UserEntity ce WHERE active=true AND ( ce.firstName IN (:firstName) OR coalesce(:firstName) IS null) "
	            + "AND ( ce.lastName IN (:lastName) OR coalesce(:lastName) IS null) "
	            + "AND ( ce.email IN (:email) OR coalesce(:email) IS null) ")
	List<UserEntity> findByUsingFilter(String firstName, String lastName, String email);

	


    



}

package com.system.management.contact.advice;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.system.management.contact.constant.AppConstants;
import com.system.management.contact.exception.EntityNotFoundExceptions;
import com.system.management.contact.exception.InvalidInputException;
import com.system.management.contact.response.BaseApiResponse;
import com.system.management.contact.response.ResponseStatus;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
public class UniversalControllerAdvice extends ResponseEntityExceptionHandler {

    @ExceptionHandler(EntityNotFoundExceptions.class)
    public ResponseEntity<BaseApiResponse> invalidInputException(EntityNotFoundExceptions entityNotFoundException,
                                                                 HttpServletRequest request) {
        BaseApiResponse baseApiResponse = new BaseApiResponse();
        baseApiResponse.setResponseStatus(new ResponseStatus(AppConstants.StatusCodes.FAILURE));
        baseApiResponse.setResponseData(entityNotFoundException);
        return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
    }

    @ExceptionHandler(InvalidInputException.class)
    public ResponseEntity<BaseApiResponse> invalidTicketException(InvalidInputException invalidInputException, HttpServletRequest request) {
        BaseApiResponse baseApiResponse = new BaseApiResponse();
        baseApiResponse.setResponseStatus(new ResponseStatus(AppConstants.StatusCodes.FAILURE));
        baseApiResponse.setResponseData(invalidInputException);
        return new ResponseEntity<>(baseApiResponse, HttpStatus.OK);
    }

}

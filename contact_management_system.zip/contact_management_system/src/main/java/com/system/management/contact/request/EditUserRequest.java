package com.system.management.contact.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EditUserRequest {

	private Long id;

	private String firstName;

	private String lastName;

	private String email;

	private String phoneNumber;

}

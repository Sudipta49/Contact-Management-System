package com.system.management.contact;

import java.util.Properties;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.system.management.contact.constant.AppConstants;

@SpringBootApplication

@EnableAsync
@EnableWebMvc
public class ContactManagementApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		new SpringApplicationBuilder(ContactManagementApplication.class).sources(ContactManagementApplication.class)
				.properties(getProperties()).run(args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder springApplicationBuilder) {
		return springApplicationBuilder.sources(ContactManagementApplication.class).properties(getProperties());
	}

	static Properties getProperties() {
		Properties props = new Properties();
		props.put("spring.config.location", AppConstants.FileLocation.PROPERTY_PATH);
		return props;
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
